import React from "react";
import Navbar from "./Navbar";
import './style.css';
import DetailedForm from "./DetailedForm";

const App = () => {
  return (
    <div className="App">
      <Navbar />
      <h1>Detailed Forms</h1>
      <DetailedForm />
    </div>
  );
};


export default App;